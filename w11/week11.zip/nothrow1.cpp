#include <iostream>
using namespace std;
int main() {
  char* p;
  int i = 0;
  try {
  do {
    p = new char[100001000000]; // really biggg
    i++;
  } while (p != NULL);

  } catch(std::bad_alloc){
    cout << "Bad allocation exception" << endl;
  }

  cout << "Out of space after " << i << " attempts!\n";
}
