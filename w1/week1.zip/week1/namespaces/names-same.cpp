int max() {

        return 100;
}

int max() {

        return 101;
}
