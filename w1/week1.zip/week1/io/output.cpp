#include <iostream>
using namespace std;

int main(){

  int x  =2;
  char y [] = "Hello";
  cout << y << x << endl;
}
