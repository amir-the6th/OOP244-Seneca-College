#include <stdio.h>

int main(){

  int x = 2;
  char y [] = "Hello";
  printf("%s %d\n", y, x);
}
