#include <stdio.h>

int main(){

        int x;
        printf("Enter a number: ");
        scanf("%d", &x);
        printf("You entered a number: %d\n", x);
}
