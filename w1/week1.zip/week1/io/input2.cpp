#include <iostream>
//using namespace std;

int main(){

  int x;
  std::cout << "Enter a number: ";
  std::cin >> x;
  std::cout << "You entered a number: " << x << std::endl;
}
