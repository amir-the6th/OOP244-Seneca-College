int add(int a, int b);
int minus_mine(int a, int b);
int sum(int arr[], int len);