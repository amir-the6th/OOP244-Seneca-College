// frame.h

struct frame{
  int frame_type;
  int frame_length;
  int frame_width;

  int getFrame_type();
  int getFrame_width();
  int getFrame_length();
};