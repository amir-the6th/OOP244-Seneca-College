// lens.h

struct lens{
  int lens_type;
  int lens_length;
  int lens_width;

  int getLens_type();
  int getLens_width();
  int getLens_length();
};