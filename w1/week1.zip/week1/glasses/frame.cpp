// frames.cpp

#include "frame.h"

int frame::getFrame_type(){
  return frame_type;
}
int frame::getFrame_length(){
  return frame_length;
}
int frame::getFrame_width(){
  return frame_width;
}