// lens.cpp

#include "lens.h"

int lens::getLens_type(){
  return lens_type;
}
int lens::getLens_length(){
  return lens_length;
}
int lens::getLens_width(){
  return lens_width;
}