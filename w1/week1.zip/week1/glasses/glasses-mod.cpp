// glasses-mod.cpp
// modular

#include "lens.h"
#include "frame.h"

struct glasses{
  struct lens ln;
  struct frame fr;

  // more glasses code...
};