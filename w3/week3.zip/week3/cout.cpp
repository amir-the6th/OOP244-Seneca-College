#include <iostream>
using namespace std;

int main(){

  int x = 25;
  cout << "1234567890" << endl;
  cout.width(10);
  cout << x << endl;
  cout.fill('$');
  cout.width(20);
  cout << x << endl;
  cout << x << endl;

  double y = 3.123456789;
  cout << "1234567890" << endl;
  cout << "Value of y: " << y << endl;
  cout.setf(ios::fixed);
  cout.precision(3);
  cout << "Value of formatted y: " << y << endl;
}
