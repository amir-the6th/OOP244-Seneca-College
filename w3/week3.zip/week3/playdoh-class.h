// playdoh-class.h

class playdoh {
  char colour; //private
  int weight; //private
  
  public:
    void setColour(char c);
    void setWeight(int w);
    void display() const;
};

const int x = 0;
