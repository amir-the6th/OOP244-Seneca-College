// input_objects1.cpp
// overview of features

#include <iostream>
using namespace std;

//#define ex1
//#define ex2

int main(){

#ifdef ex1
  char str[11];
  cout << "Enter a string with leading whitespace: " << endl;
  cin >> str; // Enter something with leading whitespace
  cout << "|" << str << "|" << endl;
#endif

#ifdef ex2
  // White space as delimiter
  cout << "Enter a string with whitespace all around: " << endl;
  cin >> str;
  cout << "|" << str << "|" << endl;
#endif

}
