// input_objects2.cpp
// member functions

#include <iostream>
using namespace std;

//#define ex1
//#define ex2
//#define ex3
int main () {

#ifdef ex1
  // Get example
  cout << "Enter csv input: ";
  char str[25];
  cin.get(str, 25, ',');
  cout << "Data start " << "|" << str << "| data end" << endl;
  char x = cin.get();
  cout << "Anything left in the buffer: " << x << " end" << endl;
#endif

#ifdef ex2
  // Getline example
  cout << "Enter csv input: ";
  char str2[25];
  cin.getline(str2, 25, ',');
  cout << "Data start " << "|" << str2 << "| data end" << endl;
  char z = cin.get();
  cout << "Anything left in the buffer: " << z << " end" << endl;
#endif

#ifdef ex3
  char first, last;

  // Ignore example
  cout << "Please, enter your first name followed by your surname: ";
  first = std::cin.get();     // get one character
  std::cin.ignore(256,' ');   // ignore until space
  last = std::cin.get();      // get one character
  cout << "Your initials are " << first << last << '\n';
  std::cin.ignore(256,'\n');   // ignore characters till new line
#endif

  return 0;
}
