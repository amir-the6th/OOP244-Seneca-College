// runtimeErrors.cpp
#include <stdio.h>

// function declarations
void foo(int);
void goo(int);
void boo(int);
void noo(int);

// function definitions
void foo(int f) {
#ifdef DEBUG
  printf("In foo\n");
#endif
  f++; boo(f); // increase f then call boo
}

void goo(int g) {
#ifdef DEBUG
  printf("In goo\n");
#endif
  g--; noo(g); // decrease g then call noo
}

void boo(int b) {
#ifdef DEBUG
  printf("In boo\n");
#endif
  b += 2; goo(b); // increase b by 2 then call goo
}

void noo(int n) {
#ifdef DEBUG
  printf("In noo\n");
#endif
  n -= 2; foo(n); // decrease n by 2 then call foo
}

int main() {
  int num = 55;
  foo(num);
  goo(num);
  boo(num);
  noo(num);
  printf("Num at the end is: %d", num);
}