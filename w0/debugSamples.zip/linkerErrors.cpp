// linkerErrors.cpp

#include <stdio.h>
#include "linkerErrors.h"

// function definitions

#define LINKERR

#ifdef LINKER
void display(mystruct s) {
  printf("mystruct's details...\n");
  displayNum(s.num);
  displayDouble(s.dnum);
  displayChar(s.letter);
}
#endif

void displayNum(int n) {
  printf("%d\n", n);
}

void displayDouble(double d) {
  printf("%1.1f\n", d);
}

void displayChar(char c) {
  printf("%c\n", c);
}
