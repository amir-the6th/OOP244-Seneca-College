// simpleBuildErrors
// C style code

#include <stdio.h>

int add(int a, int b) {
  return a + b;
}

int add(int a, int b) {
  return a - b;
}

int main() {

  int x = add(1, 2);
  char y = add(3, 4);
  char z[5] = 'a';

  printf("%d\n", x);
  printf("%c\n", y);
  printf("%s\n", z);

  return 0;
}