#include "linkerErrors.h"

int main() {

  struct mystruct s;
  s.num = 1;
  s.dnum = 2.2;
  s.letter = 'a';

  display(s);

  return 0;
}