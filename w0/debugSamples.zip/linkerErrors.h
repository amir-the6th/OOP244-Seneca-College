// linkerErrors.h

struct mystruct {
  int num;
  double dnum;
  char letter;
};

// function declarations

void display(mystruct s);
void displayNum(int n);
void displayDouble(double d);
void displayChar(char c);