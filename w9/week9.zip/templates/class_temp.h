// class_temp.h
template <class T, int N>
class Array{
  T arr[N];

  public:
    T& operator[](int i) { return arr[i];}
};
