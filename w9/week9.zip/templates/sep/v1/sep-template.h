// sep-template.h
template <typename T>
void myswap(T& a, T& b);
