#include <iostream>
#include "sep-template.h"
using namespace std;

int main() {

  int a = 1;
  int b = 2;
  myswap(a, b);
}
