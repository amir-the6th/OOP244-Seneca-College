// function_temp.cpp
#include <iostream>
#include "function_temp.h"
//#define active

#ifdef active
int main(){
  
  int x = 1, y = 2;
  swap(x, y); 
  // Compiler generates the code needed for 
  // the int version of swap above
  std::cout << "x : " << x << " y: " << y << std::endl;

  double c = 1.5, d = 2.5;
  swap(c, d); // Similarly for the double verison
  std::cout << "c : " << c << " d: " << d << std::endl;
}
#endif
