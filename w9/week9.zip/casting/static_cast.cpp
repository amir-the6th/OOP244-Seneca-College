// static_cast.cpp
#include <iostream>
using namespace std;
//#define active
//#define ex1
//#define ex2

#ifdef active
int main(){

  #ifdef ex1
  // Fundemental type example
  double hours = 0;
  int min = 37;
  
  //hours = double(min) / 60; // c style (function style)
  //hours = (double)min / 60; // c style
  hours = static_cast<double>(min) / 60; // int and float are related
  cout << min<< " minutes in hours is " << hours << endl; 
  #endif

  #ifdef ex2
  // Error example
  int x = 2;
  int* p;
  p = (int*)(x);
  //p = static_cast<int*>(x); // FAILS: unrelated types, compile error 
  cout << "what is p: " << p << endl;  

  // Error example2
  char a = 65; // 65 is 'A'
  cout << "what is a: " << a << endl;
  int* q = (int*)(&a);
  //int *q = static_cast<int*>(&a); // FAILS
  cout << "what is q's value: " << q << endl;
  #endif
}
#endif
