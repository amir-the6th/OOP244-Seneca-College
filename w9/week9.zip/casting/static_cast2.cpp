// static_cast2.cpp
// static casting w/ class in heirarchy
#include <iostream>
using namespace std;

class dummyA {
  int resourceA;
  public:
    dummyA() { cout << "dummyA class" << endl; resourceA = 3; }    
    void display() { cout << "displaying from A: " << resourceA << endl; }
};

class dummyB : public dummyA {
  int resourceB;
  public:
    dummyB() { cout << "dummyB class" << endl; resourceB = 4;}
    void show() { cout << "displaying from B: " << resourceB << endl; }
    void action() { cout << "performing an action from B" << endl; }
};

//#define active
#ifdef active
int main(){
  // Class example from base to derived
  dummyA* da = new dummyA();
  dummyB* db;
  db = static_cast<dummyB*>(da);
  db->display();
  db->show();
  db->action();
  delete db;
  cout << "*****************" << endl;
  // from derived to base
  dummyB* dc = new dummyB();
  dummyA* dd = static_cast<dummyA*>(dc);
  dd->display();
  delete dd;
}
#endif
