// const_cast.cpp

#include <iostream>
using namespace std;

//#define active
//#define ex1
//#define ex2

void foo(int* p) {
    cout << *p << endl;
}

#ifdef active
int main( ) {
    const int x = 3;
    const int* a = &x;
    int* b;

    // foo expects int* and not const int*
    #ifdef ex1
    b = const_cast<int*>(a);  // remove const status 
    #endif
    foo(b);

    #ifdef ex2
    const int x = 2;
    double y;
    y = const_cast<double>(x); // FAILS with unrelated types
    #endif
}
#endif
