#include <iostream>
using namespace std;

int x = 99;

int main(){

  //int x = 0;
  for (int x = 0; x < 10; x++){
    cout << x;
  } 

  cout << x << endl;
  return 0;
}
