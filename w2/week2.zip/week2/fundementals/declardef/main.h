// main.h

struct furniture;
void display(furniture furn);
void increaseSize(furniture furn, int s);
void decreaseSize(int s, furniture furn);