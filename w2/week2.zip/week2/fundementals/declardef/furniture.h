// furniture.h

struct furniture{
  char name[10];
  int size;
};