//playdoh.h
//

struct playdoh {
  char colour;
  int weight;
};

void setColour(char c, playdoh* p);
void setWeight(int w, playdoh* p);
