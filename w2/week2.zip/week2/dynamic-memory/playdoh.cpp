//playdoh.cpp
//

#include "playdoh.h"

void setColour(char c, playdoh* p){
       p->colour = c; 
}

void setWeight(int w, playdoh* p){
       p->weight = w; 
}
