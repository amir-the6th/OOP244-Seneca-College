// num.cpp
//
#include <iostream>
using namespace std;

int main(){

  int x = 123456789;

  cout << "x : " << x << endl;
  cout << "x % 10 : " << x % 10 << endl;
  cout << "x / 10 : " << x / 10 << endl;
  cout << "(x / 10) % 10 : " << (x / 10) % 10 << endl;

  //for (int i = 0; i < 9; i++){

  //   cout << "x : " << x << endl;
  //   cout << " x % 10 : " << x % 10 << endl;
  //   x /= 10;
  //}

}
